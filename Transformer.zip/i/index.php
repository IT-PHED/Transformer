<?php
header('location:i/');
?>